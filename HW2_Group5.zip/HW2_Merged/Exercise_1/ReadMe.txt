Steps for execution:
1. Run the Writer program in the Writer/out/build directory to write to the shared memory from one terminal.
2. Run the Reader program in the Reader/out/build directory to read from the shared memory in a second terminal.
3. Type exit in the first terminal to terminate the Writer program and clean up the shared memory.

Documentation:
* Boost needs to be included during compilation.
* Programs were generated almost entirely with ChatGPT -- minor edits were made to resolve errors.
* ChatGPT was used to assist with inclusion of Boost in the Makefile.
