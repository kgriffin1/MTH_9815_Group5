Steps for execution:
1. Run Exercise_2_3 in the out/build/ directory.
2. Boost library needs to be included when compiling.

Documentation:
* ChatGPT was not used.